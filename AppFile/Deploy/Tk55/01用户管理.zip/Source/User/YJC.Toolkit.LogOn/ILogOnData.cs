﻿namespace YJC.Toolkit.LogOn
{
    public interface ILogOnData
    {
        LogOnData LogOnData { get; }
    }
}
