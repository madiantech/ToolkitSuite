﻿namespace YJC.Toolkit.SimpleRight
{
    internal static class RightConst
    {
        public const string USER_INFO_COOKIE_NAME = "UserLogOnInfo";
    }
}
