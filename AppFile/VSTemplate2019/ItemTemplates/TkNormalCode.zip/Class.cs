﻿using System;
using System.Collections.Generic;
using System.Linq;
using YJC.Toolkit.Sys;

namespace $rootnamespace$
{
	internal class $safeitemrootname$
	{
	}
}
