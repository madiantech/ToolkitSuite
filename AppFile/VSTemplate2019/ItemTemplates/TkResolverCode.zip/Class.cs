﻿using System;
using System.Data;
using YJC.Toolkit.Data;
using YJC.Toolkit.MetaData;
using YJC.Toolkit.Sys;

namespace $rootnamespace$
{
    [Resolver(Author = "$username$", CreateDate = "$time$",
        Description = "()的数据访问层类")]
	internal class $fileinputname$Resolver : Tk5TableResolver
    {
        private const string DATAXML = "$fileinputname$.xml";

        public $fileinputname$Resolver(IDbDataSource source)
            : base(DATAXML, source)
        {
            AutoTrackField = true;
            AutoUpdateKey = true;
        }

        protected override void OnUpdatingRow(UpdatingEventArgs e)
        {
            base.OnUpdatingRow(e);

            switch (e.Status)
            {
                case UpdateKind.Insert:
                    break;
                case UpdateKind.Update:
                    break;
                case UpdateKind.Delete:
                    break;
            }
        }
    }
}
