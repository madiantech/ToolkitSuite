﻿using YJC.Toolkit.Sys;

namespace $rootnamespace$
{
    public class $fileinputname$ConfigFactory : BaseXmlConfigFactory
    {
        public const string REG_NAME = "_tk_xml_$fileinputname$";
        private const string DESCRIPTION = "$fileinputname$配置插件工厂";

        public $fileinputname$ConfigFactory()
            : base(REG_NAME, DESCRIPTION)
        {
        }
    }
}
