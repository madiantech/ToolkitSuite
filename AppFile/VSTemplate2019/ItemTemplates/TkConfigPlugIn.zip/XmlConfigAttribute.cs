﻿using System;
using YJC.Toolkit.Sys;

namespace $rootnamespace$
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    public sealed class $fileinputname$ConfigAttribute : BaseObjectElementAttribute
    {
        public override string FactoryName
        {
            get
            {
                return $fileinputname$ConfigFactory.REG_NAME;
            }
        }
    }
}
