﻿using System;
using YJC.Toolkit.Sys;

namespace $rootnamespace$
{
    public class $fileinputname$PlugInFactory : BasePlugInFactory
    {
        public const string REG_NAME = "_tk_$fileinputname$";
        private const string DESCRIPTION = "$fileinputname$插件工厂";

        public $fileinputname$PlugInFactory()
            : base(REG_NAME, DESCRIPTION)
        {
        }
    }
}
