﻿using System;
using YJC.Toolkit.Sys;

namespace $rootnamespace$
{
    [AttributeUsage(AttributeTargets.Class, Inherited = false, AllowMultiple = false)]
    public sealed class $fileinputname$Attribute : BasePlugInAttribute
    {
        public $fileinputname$Attribute()
        {
            Suffix = "$fileinputname$";
        }

        public override string FactoryName
        {
            get
            {
                return $fileinputname$PlugInFactory.REG_NAME;
            }
        }
    }
}
