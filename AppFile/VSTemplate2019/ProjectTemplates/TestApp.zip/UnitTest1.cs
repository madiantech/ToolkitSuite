﻿using System;
using System.IO;
using Xunit;
using YJC.Toolkit.Sys;
using static Xunit.Assert;

namespace $safeprojectname$
{
    public class UnitTest1 : IClassFixture<ToolkitFixture>
    {
        public UnitTest1(ToolkitFixture data)
        {
        }

		//[Fact]
        //public void Test1()
        //{
        //}
	}
}
