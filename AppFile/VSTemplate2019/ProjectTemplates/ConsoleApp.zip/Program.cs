﻿using System;
using YJC.Toolkit.Sys;

namespace $safeprojectname$
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            if (!ConsoleApp.Initialize())
                return;

            Console.ReadKey();
        }
	}
}
